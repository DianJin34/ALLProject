name: Dian
cs login: dian
wisc ID: 9082014714
email: djin34@wisc.edu
status of implementation: All test pass