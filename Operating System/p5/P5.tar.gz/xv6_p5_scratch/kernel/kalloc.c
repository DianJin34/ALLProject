// Physical memory allocator, intended to allocate
// memory for user processes, kernel stacks, page table pages,
// and pipe buffers. Allocates 4096-byte pages.

#include "types.h"
#include "defs.h"
#include "param.h"
#include "mmu.h"
#include "spinlock.h"

struct run {
  struct run *next;
};

struct {
  struct spinlock lock;
  struct run *freelist;

  /*
  P5 changes
  */
  uint free_pages; //track free pages
  uint ref_cnt[PHYSTOP / PGSIZE]; //track reference count

} kmem;

extern char end[]; // first address after kernel loaded from ELF file

// Initialize free list of physical pages.
void
kinit(void)
{
  initlock(&kmem.lock, "kmem");
  char *p = (char*)PGROUNDUP((uint)end);

  kmem.free_pages = 0;
  for(; p + PGSIZE <= (char*)PHYSTOP; p += PGSIZE)
  {
    kmem.ref_cnt[(uint)p >> PGSHIFT] = 1;
    kfree(p);
  }

}

// Free the page of physical memory pointed at by v,
// which normally should have been returned by a
// call to kalloc().  (The exception is when
// initializing the allocator; see kinit above.)
void
kfree(char *v)
{
  struct run *r;

  if((uint)v % PGSIZE || v < end || (uint)v >= PHYSTOP) 
    panic("kfree");
  int index = ((uint)v >> PGSHIFT);
  // if(kmem.ref_cnt[index] != 1)
  // {
  //   cprintf("index: %d, num: %d\n", index, kmem.ref_cnt[index]);
  //   panic("kfree");
  // }

  acquire(&kmem.lock);
  if(kmem.ref_cnt[index] > 0)
    kmem.ref_cnt[index] -= 1;

  // Fill with junk to catch dangling refs.
  if(kmem.ref_cnt[index] == 0)
  {
    memset(v, 1, PGSIZE);
    r = (struct run*)v;
    r->next = kmem.freelist;
    kmem.freelist = r;
    kmem.free_pages += 1;
  }
  release(&kmem.lock);
}

// Allocate one 4096-byte page of physical memory.
// Returns a pointer that the kernel can use.
// Returns 0 if the memory cannot be allocated.
char*
kalloc(void)
{
  struct run *r;

  acquire(&kmem.lock);
  r = kmem.freelist;
  if(r)
  {
    kmem.freelist = r->next;
    kmem.free_pages -= 1;
    kmem.ref_cnt[(uint)r >> PGSHIFT] = 1;
  }
  release(&kmem.lock);
  return (char*)r;
}


int
getFreePagesCount(void){
  acquire(&kmem.lock);
  int num_free_pages = kmem.free_pages;
  release(&kmem.lock);
  return num_free_pages;
}

void 
increment_page_usage(uint pa)
{
  int index = (pa >> PGSHIFT);
  // cprintf("call increment_page_usage by pa %p with index: %d\n", (char *)pa, index);
  acquire(&kmem.lock);
  kmem.ref_cnt[index] += 1;
  release(&kmem.lock);
}

void 
decrement_page_usage(uint pa)
{
  int index = (pa >> PGSHIFT);
  // cprintf("call decrement_page_usage by pa %p with index: %d\n", (char *)pa, index);
  acquire(&kmem.lock);
  kmem.ref_cnt[index] -= 1;
  release(&kmem.lock);
}

int
get_page_usage(uint pa)
{
  int index = (pa >> PGSHIFT);
  // cprintf("call get_page_usage by pa %p with index: %d\n", (char *)pa, index);
  acquire(&kmem.lock);
  int page_ref_cnt = kmem.ref_cnt[index];
  release(&kmem.lock);
  return page_ref_cnt;
}